$(document).ready(function () {

	var selector;
	var sliderItem;


	$('.promo__slider').on('setPosition', function(){
		sliderItem = $('[data-slick-index]');
		sliderItem.removeClass('dop-left dop-right');
		var next = sliderItem.filter('.slick-current');
		next.prev().addClass('dop-right');
		next.next().addClass('dop-left');
	});

	$('.promo__slider').on('beforeChange', function(event, { slideCount: count }, currentSlide, nextSlide){
		var id = [nextSlide, nextSlide - count, nextSlide + count];

		for(var i = 0; i < id.length; i++){
			if(i === 0) {
				selector = '[data-slick-index="' + id[i] + '"]';
			} else {
				selector += ',[data-slick-index="' + id[i] + '"]';
			}
		}

		var next = $(selector);
		
		next.addClass('active');
		sliderItem.removeClass('dop-left dop-right');
		next.prev().addClass('dop-right');
		next.next().addClass('dop-left');
	  });

	  $('.promo__slider').on('afterChange', function(){
		$(selector).removeClass('active');
	  });
	  $('.promo__slider').slick({
		arrows: false,
		dots: true,
		slidesToShow: 1,
		speed: 600,
		// fade: true,
		centerMode: true,
	});


	$("a[href^='#']").click(function () {
		var _href = $(this).attr("href");
		$("html, body").animate({ scrollTop: $(_href).offset().top - 100 },);
		return false;
	});

	$('.doctors__slider>.slick-list>.slick-track>.slick-slide').removeClass('dop-right');

	const swiper = new Swiper('.doctors__slider', {
		// spaceBetween: 30,
		slidesPerView: 1,
		spaceBetween: 100,
		// effect: "flip",
        // grabCursor: true,
		breakpoints: {
			1120: {
			  slidesPerView: 2,
			  spaceBetween: 52
			}
		  },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });

	  const swiper2 = new Swiper('.users__slider', {
		// spaceBetween: 30,
		slidesPerView: 1,
		spaceBetween: 100,

		breakpoints: {

			1120: {
			  slidesPerView: 3,
			  spaceBetween: 51
			}
		  },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });


	  

	  



function slickify() {
	if ($('.fight__slider').hasClass('slick-initialized')) {
		$('.fight__slider').slick('destroy');
	}

}
slickify();
$(window).resize(function () {
	var $windowWidth = $(window).width();
	if ($windowWidth < 1330) {
		slickify();
	}
});
});

function resizeBlock() {
	//  if(window.matchMedia("screen and (max-width: 1210px)").matches) {
	//     $('.autor').append($('.autor-mob'));
	//   }
	if (window.matchMedia("screen and (min-width: 990px)").matches) {
	  $('.weapon__items').appendTo($('#web'));
	//   $('.weapon__weeks').appendTo($('#web'));
	}
	else if(window.matchMedia("screen and (max-width: 990px)").matches) {

		$('.weapon__items').appendTo($('#mob'));
		// $('.weapon__weeks').appendTo($('#mob'));
	}
	if (window.matchMedia("screen and (min-width: 1220px)").matches) {
	    $('.weapon__weeks').appendTo($('#web'));
	  }
	  else if(window.matchMedia("screen and (max-width: 990px)").matches) {

		$('.weapon__weeks').appendTo($('#mob'));
	}
  }

  $(window).resize(function () {
	resizeBlock();
  });

  $(document).ready(function () {
	resizeBlock();
  });

